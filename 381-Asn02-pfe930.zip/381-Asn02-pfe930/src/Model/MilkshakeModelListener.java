package Model;

public interface MilkshakeModelListener {
        public void modelChanged();
}
