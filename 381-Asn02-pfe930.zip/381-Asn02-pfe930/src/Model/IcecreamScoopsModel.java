package Model;

import View.DisplayMissage;

import java.util.ArrayList;

public class IcecreamScoopsModel {

    private final double ScoopsPrice = 1.00;

    private int ScoopsCount;

    private int ChocolateCount;
    private int VanillaCount;
    private int StrawberryCount;
    private int LemonCount;
    private int CoffeeCount;
    private int MintCount;

    private ArrayList<MilkshakeModelListener> Subscribers;

    public IcecreamScoopsModel(){
        ScoopsCount = 0;

        ChocolateCount = 0;
        VanillaCount = 0;
        StrawberryCount = 0;
        LemonCount = 0;
        CoffeeCount = 0;
        MintCount = 0;

        Subscribers = new ArrayList<>();
    }

    public void ClearScoops(){
        ScoopsCount = 0;

        ChocolateCount = 0;
        VanillaCount = 0;
        StrawberryCount = 0;
        LemonCount = 0;
        CoffeeCount = 0;
        MintCount = 0;

        NotifySubscribers();
    }

    public void AddSubscriber(MilkshakeModelListener nListener){
        Subscribers.add(nListener);
    }

    private void NotifySubscribers() {
        Subscribers.forEach(sub -> sub.modelChanged());
    }

    public double GetScoopsPrice(){ return (ScoopsCount * ScoopsPrice); }

    public int GetScoopsCount(){ return ScoopsCount; }

    public int GetVanillaCount(){ return VanillaCount; }

    public int GetStrawberryCount(){ return StrawberryCount; }

    public int GetLemonCount(){ return LemonCount; }

    public int GetCoffeeCount(){ return CoffeeCount; }

    public int GetMintCount(){ return MintCount; }

    public int GetChocolateCount(){ return ChocolateCount; }

    private void IncreaseScoopsCount(){ this.ScoopsCount++; NotifySubscribers(); }

    private void DecreaseScoopsCount(){ this.ScoopsCount--; NotifySubscribers(); }

    public Boolean IncreaseChocolateCount(){
        if(this.GetScoopsCount() <= 7){
            this.ChocolateCount++;
            IncreaseScoopsCount();
            return true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 8 scoops.",1);
            return false;
        }
    }

    public Boolean IncreaseVanillaCount(){
        if(this.GetScoopsCount() <= 7){
            this.VanillaCount++;
            IncreaseScoopsCount();
            return true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 8 scoops.",1);
            return false;
        }
    }

    public Boolean IncreaseStrawberryCount(){
        if(this.GetScoopsCount() <= 7){
            this.StrawberryCount++;
            IncreaseScoopsCount();
            return true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 8 scoops.",1);
            return false;
        }
    }

    public Boolean IncreaseLemonCount(){
        if(this.GetScoopsCount() <= 7){
            this.LemonCount++;
            IncreaseScoopsCount();
            return true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 8 scoops.",1);
            return false;
        }
    }

    public Boolean IncreaseCoffeeCount(){
        if(this.GetScoopsCount() <= 7){
            this.CoffeeCount++;
            IncreaseScoopsCount();
            return true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 8 scoops.",1);
            return false;
        }
    }

    public Boolean IncreaseMintCount(){
        if(this.GetScoopsCount() <= 7){
            this.MintCount++;
            IncreaseScoopsCount();
            return true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 8 scoops.",1);
            return false;
        }
    }

    public void DecreaseChocolateCount(){
        if(this.GetChocolateCount() >= 1){
            this.ChocolateCount--;
            DecreaseScoopsCount();
        } else {
            System.out.println("User attempted to decrease Chocolate passed 0.");
        }
    }

    public void DecreaseVanillaCount(){
        if(this.GetVanillaCount() >= 1){
            this.VanillaCount--;
            DecreaseScoopsCount();
        } else {
            System.out.println("User attempted to decrease Vanilla passed 0.");
        }
    }

    public void DecreaseStrawberryCount(){
        if(this.GetStrawberryCount() >= 1){
            this.StrawberryCount--;
            DecreaseScoopsCount();
        } else {
            System.out.println("User attempted to decrease Strawberry Chips passed 0.");
        }
    }

    public void DecreaseLemonCount(){
        if(this.GetLemonCount() >= 1){
            this.LemonCount--;
            DecreaseScoopsCount();
        } else {
            System.out.println("User attempted to decrease Lemon passed 0.");
        }
    }

    public void DecreaseCoffeeCount(){
        if(this.GetCoffeeCount() >= 1){
            this.CoffeeCount--;
            DecreaseScoopsCount();
        } else {
            System.out.println("User attempted to decrease Coffee passed 0.");
        }
    }

    public void DecreaseMintCount(){
        if(this.GetMintCount() >= 1){
            this.MintCount--;
            DecreaseScoopsCount();
        } else {
            System.out.println("User attempted to decrease Mint passed 0.");
        }
    }

    public String GetAllScoops(){
        ArrayList<String> ScoopsList = new ArrayList<>();

        if(GetChocolateCount() > 0){
            ScoopsList.add( GetChocolateCount() + " Chocolate");
        }

        if(GetVanillaCount() > 0){
            ScoopsList.add( GetVanillaCount() + " Vanilla");
        }

        if(GetStrawberryCount() > 0){
            ScoopsList.add( GetStrawberryCount() + " Strawberry");
        }

        if(GetLemonCount() > 0){
            ScoopsList.add( GetLemonCount() + " Lemon");
        }

        if(GetCoffeeCount() > 0){
            ScoopsList.add( GetCoffeeCount() + " Coffee");
        }

        if(GetMintCount() > 0){
            ScoopsList.add( GetMintCount() + " Mint");
        }

        String strScoops = "";

        for(int i = 0; i <= ScoopsList.size() - 1; i++){
            strScoops += ScoopsList.get(i) + "\n";
        }

        return strScoops;

    }
}
