package Model;

import View.DisplayMissage;

import java.util.ArrayList;

public class ToppingsModel  {

    private final double ToppingsPrice = 0.50;

    private int ToppingsCount;

    private int SprinklesCount;
    private int CherriesCount;
    private int ChocolateChipsCount;
    private int WhippedCreamCount;
    private int CoconutCount;
    private int MarshmallowsCount;

    private ArrayList<MilkshakeModelListener> Subscribers;

    public ToppingsModel(){
        // Toppings \\
        ToppingsCount = 0;

        SprinklesCount = 0;
        CherriesCount = 0;
        ChocolateChipsCount = 0;
        WhippedCreamCount = 0;
        CoconutCount = 0;
        MarshmallowsCount = 0;

        Subscribers = new ArrayList<>();
    }

    public void ClearToppings(){
        ToppingsCount = 0;

        SprinklesCount = 0;
        CherriesCount = 0;
        ChocolateChipsCount = 0;
        WhippedCreamCount = 0;
        CoconutCount = 0;
        MarshmallowsCount = 0;

        NotifySubscribers();
    }

    public void AddSubscriber(MilkshakeModelListener nListener){
        Subscribers.add(nListener);
    }

    private void NotifySubscribers() {
        Subscribers.forEach(sub -> sub.modelChanged());
    }

    public double GetToppingsPrice(){ return (ToppingsCount * ToppingsPrice); }

    public int GetToppingsCount(){ return ToppingsCount; }

    public int GetSprinklesCount(){ return SprinklesCount; }

    public int GetCherriesCount(){ return CherriesCount; }

    public int GetChocolateChipsCount(){ return ChocolateChipsCount; }

    public int GetWhippedCreamCount(){ return WhippedCreamCount; }

    public int GetCoconutCount(){ return CoconutCount; }

    public int GetMarshmallowsCount(){ return MarshmallowsCount; }

    private void IncreaseToppingsCount(){ this.ToppingsCount++; NotifySubscribers(); }

    public Boolean IncreaseSprinklesCount(){
        if(this.ToppingsCount <= 5){
            this.SprinklesCount++;
            IncreaseToppingsCount();
            return  true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 6 toppings.",1);
            return false;
        }
    }

    public Boolean IncreaseCherriesCount(){
        if(this.ToppingsCount <= 5){
            this.CherriesCount++;
            IncreaseToppingsCount();
            return true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 6 toppings.",1);
            return false;
        }
    }

    public Boolean IncreaseChocolateChipsCount(){
        if(this.ToppingsCount <= 5){
            this.ChocolateChipsCount++;
            IncreaseToppingsCount();
            return true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 6 toppings.",1);
            return false;
        }
    }

    public Boolean IncreaseWhippedCreamCount(){
        if(this.ToppingsCount <= 5){
            this.WhippedCreamCount++;
            IncreaseToppingsCount();
            return true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 6 toppings.",1);
            return false;
        }
    }

    public Boolean IncreaseCoconutCount(){
        if(this.ToppingsCount <= 5){
            this.CoconutCount++;
            IncreaseToppingsCount();
            return true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 6 toppings.",1);
            return false;
        }
    }

    public Boolean IncreaseMarshmallowsCount(){
        if(this.ToppingsCount <= 5){
            this.MarshmallowsCount++;
            IncreaseToppingsCount();
            return true;
        } else {
            new DisplayMissage("Oops!", "You can only enter up to 6 toppings.",1);
            return false;
        }
    }

    private void DecreaseToppingsCount(){ this.ToppingsCount--; NotifySubscribers(); }

    public void DecreaseSprinklesCount(){
        if(this.SprinklesCount >= 1){
            this.SprinklesCount--;
            DecreaseToppingsCount();
        } else {
            System.out.println("User attempted to decrease Sprinkles passed 0.");
        }
    }

    public void DecreaseCherriesCount(){
        if(this.CherriesCount >= 1){
            this.CherriesCount--;
            DecreaseToppingsCount();
        } else {
            System.out.println("User attempted to decrease Cherries passed 0.");
        }
    }

    public void DecreaseChocolateChipsCount(){
        if(this.ChocolateChipsCount >= 1){
            this.ChocolateChipsCount--;
            DecreaseToppingsCount();
        } else {
            System.out.println("User attempted to decrease Chocolate Chips passed 0.");
        }
    }

    public void DecreaseWhippedCreamCount(){
        if(this.WhippedCreamCount >= 1){
            this.WhippedCreamCount--;
            DecreaseToppingsCount();
        } else {
            System.out.println("User attempted to decrease Whipped Cream passed 0.");
        }
    }

    public void DecreaseCoconutCount(){
        if(this.CoconutCount >= 1){
            this.CoconutCount--;
            DecreaseToppingsCount();
        } else {
            System.out.println("User attempted to decrease Coconut passed 0.");
        }
    }

    public void DecreaseMarshmallowsCount(){
        if(this.MarshmallowsCount >= 1){
            this.MarshmallowsCount--;
            DecreaseToppingsCount();
        } else {
            System.out.println("User attempted to decrease Marshmallows passed 0.");
        }
    }

    public String GetAllToppings(){
        ArrayList<String> ToppingsList = new ArrayList<>();

        if(GetSprinklesCount() > 0){
            ToppingsList.add( GetSprinklesCount() + " Sprinkles");
        }

        if(GetCherriesCount() > 0){
            ToppingsList.add( GetCherriesCount() + " Cherries");
        }

        if(GetChocolateChipsCount() > 0){
            ToppingsList.add( GetChocolateChipsCount() + " Chocolate Chips");
        }

        if(GetWhippedCreamCount() > 0){
            ToppingsList.add( GetWhippedCreamCount() + " Whipped Cream");
        }

        if(GetCoconutCount() > 0){
            ToppingsList.add( GetCoconutCount() + " Coconut");
        }

        if(GetMarshmallowsCount() > 0){
            ToppingsList.add( GetMarshmallowsCount() + " Marshmallows");
        }

        String strToppings = "";

        for(int i = 0; i <= ToppingsList.size() - 1; i++){
            strToppings += ToppingsList.get(i) + "\n";
        }

        return strToppings;
    }


}
