package Model;

import javafx.geometry.Point2D;
import javafx.scene.image.Image;

import java.awt.*;
import java.util.ArrayList;

public class PictureModel {

    private ArrayList<MilkshakeModelListener> Subscribers;
    private ArrayList<MilkshakeIcon> IconsList;

    private Image scoop_Chocolate, scoop_Coffee, scoop_Lemon, scoop_Mint, scoop_Strawberry, scoop_Vanilla;
    private Image topping_Cherries, topping_ChocolateChips, toppings_Coconut, toppings_Marshmallows, toppings_Sprinkles, toppings_WhippedCream;

    public PictureModel(){

        Subscribers = new ArrayList<>();
        IconsList = new ArrayList<>();

        scoop_Chocolate = new Image("/Resources/IcecreamIcons/icecream-chocolate-100.png");
        scoop_Coffee = new Image("/Resources/IcecreamIcons/icecream-coffee-100.png");
        scoop_Lemon = new Image("/Resources/IcecreamIcons/icecream-lemon-100.png");
        scoop_Mint = new Image("/Resources/IcecreamIcons/icecream-mint-100.png");
        scoop_Strawberry = new Image("/Resources/IcecreamIcons/icecream-strawberry-100.png");
        scoop_Vanilla = new Image("/Resources/IcecreamIcons/icecream-vanilla-100.png");

        topping_Cherries = new Image("/Resources/ToppingsIcons/topping-cherries-100.png");
        topping_ChocolateChips = new Image("/Resources/ToppingsIcons/topping-chocolatebar-100.png");
        toppings_Coconut = new Image("/Resources/ToppingsIcons/topping-coconut-100.png");
        toppings_Marshmallows = new Image("/Resources/ToppingsIcons/topping-marshmallows-100.png");
        toppings_Sprinkles = new Image("/Resources/ToppingsIcons/topping-sprinkles-100.png");
        toppings_WhippedCream = new Image("/Resources/ToppingsIcons/topping-whippedcream-100.png");
    }

    public void AddSubscriber(MilkshakeModelListener nListener){
        Subscribers.add(nListener);
    }

    private void NotifySubscribers() {
        Subscribers.forEach(sub -> sub.modelChanged());
    }

    public Image getScoop_Chocolate() {
        return scoop_Chocolate;
    }

    public Image getScoop_Coffee() {
        return scoop_Coffee;
    }

    public Image getScoop_Lemon() {
        return scoop_Lemon;
    }

    public Image getScoop_Mint() {
        return scoop_Mint;
    }

    public Image getScoop_Strawberry() {
        return scoop_Strawberry;
    }

    public Image getScoop_Vanilla() {
        return scoop_Vanilla;
    }

    public Image getTopping_Cherries() {
        return topping_Cherries;
    }

    public Image getTopping_ChocolateChips() {
        return topping_ChocolateChips;
    }

    public Image getToppings_Coconut() {
        return toppings_Coconut;
    }

    public Image getToppings_Marshmallows() {
        return toppings_Marshmallows;
    }

    public Image getToppings_Sprinkles() {
        return toppings_Sprinkles;
    }

    public Image getToppings_WhippedCream() {
        return toppings_WhippedCream;
    }

    public void AddMilkshakeIcon(String nType){

        MilkshakeIcon nIcon = null;

        switch(nType){
            case "Sprinkles":
                nIcon = new MilkshakeIcon(getToppings_Sprinkles(), "Sprinkles");
                break;
            case "Cherries":
                nIcon = new MilkshakeIcon(getTopping_Cherries(), "Cherries");
                break;
            case "ChocolateChips":
                nIcon = new MilkshakeIcon(getTopping_ChocolateChips(), "ChocolateChips");
                break;
            case "WhippedCream":
                nIcon = new MilkshakeIcon(getToppings_WhippedCream(), "WhippedCream");
                break;
            case "Coconut":
                nIcon = new MilkshakeIcon(getToppings_Coconut(), "Coconut");
                break;
            case "Marshmallows":
                nIcon = new MilkshakeIcon(getToppings_Marshmallows(),"Marshmallows");
                break;
            case "Chocolate":
                nIcon = new MilkshakeIcon(getScoop_Chocolate(),"Chocolate");
                break;
            case "Vanilla":
                nIcon = new MilkshakeIcon(getScoop_Vanilla(),"Vanilla");
                break;
            case "Strawberry":
                nIcon = new MilkshakeIcon(getScoop_Strawberry(),"Strawberry");
                break;
            case "Lemon":
                nIcon = new MilkshakeIcon(getScoop_Lemon(),"Lemon");
                break;
            case "Coffee":
                nIcon = new MilkshakeIcon(getScoop_Coffee(),"Coffee");
                break;
            case "Mint":
                nIcon = new MilkshakeIcon(getScoop_Mint(),"Mint");
                break;
            default:
                break;
        }

        if(nIcon != null){
            IconsList.add(nIcon);
            NotifySubscribers();
        }
    }

    public void RemoveMilkshakeIcon(String nType){
        for(int i = IconsList.size() - 1; i >= 0; i--){
            if(IconsList.get(i).getIconType() == nType){
                IconsList.remove(i);
                break;
            }
        }

        NotifySubscribers();
    }

    public ArrayList<MilkshakeIcon> GetIconsList(){
        return IconsList;
    }

    public int GetMilkshakeIconArrayListSize(){
        return IconsList.size();
    }

    public MilkshakeIcon GetIconAtIndex(int index){
        return IconsList.get(index);
    }

    public void RemoveAllIcons(){
        IconsList.clear();
        NotifySubscribers();
    }
}
