package Model;

import View.ToppingsView;

import java.text.NumberFormat;
import java.util.ArrayList;

public class MainSystemModel {

    private ArrayList<MilkshakeModelListener> Subscribers;
    private double OrderTotal;
    private ToppingsModel ToppingsModel;
    private IcecreamScoopsModel IcecreamScoopsModel;

    public MainSystemModel(){
        Subscribers = new ArrayList<>();
    }

    public void SetToppingsModel(ToppingsModel nModel){
        this.ToppingsModel = nModel;
    }

    public void SetIceCreamScoopsModel(IcecreamScoopsModel nModel){
        this.IcecreamScoopsModel = nModel;
    }

    public double GetToppingsPrice(){
        return this.ToppingsModel.GetToppingsPrice();
    }

    public double GetScoopsPrice(){
        return this.IcecreamScoopsModel.GetScoopsPrice();
    }

    public void AddSubscriber(MilkshakeModelListener nListener){
        Subscribers.add(nListener);
    }

    private void NotifySubscribers() {
        Subscribers.forEach(sub -> sub.modelChanged());
    }

    public void CalculateOrderTotal(){
        OrderTotal = GetToppingsPrice() + GetScoopsPrice();
        NotifySubscribers();
    }

    public String GetOrderTotalAsMoneyFormat(){
        NumberFormat formatter = NumberFormat.getCurrencyInstance();
        return formatter.format(this.OrderTotal);
    }

    public double GetOrderTotalAsDouble() { return this.OrderTotal; }

}
