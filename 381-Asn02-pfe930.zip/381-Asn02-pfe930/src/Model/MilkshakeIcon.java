package Model;

import javafx.scene.image.Image;
import javafx.geometry.Point2D;

public class MilkshakeIcon {

    private Image Icon;
    private String IconType;

    public MilkshakeIcon(Image nIcon, String nIconType){
        Icon = nIcon;
        IconType = nIconType;
    }

    public Image getIconImage() {
        return Icon;
    }

    public void setIcon(Image icon) {
        Icon = icon;
    }

    public String getIconType(){
        return IconType;
    }

    public void setIconType(String nType){
        IconType = nType;
    }
}
