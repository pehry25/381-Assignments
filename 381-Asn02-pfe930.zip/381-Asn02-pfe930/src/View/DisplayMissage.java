package View;

import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javax.swing.*;
import javax.swing.text.Element;

public class DisplayMissage {

    public DisplayMissage(String Title, String Message, int MessageType){

        Image nImage = null;
        if(MessageType == 0){
            nImage = new Image(getClass().getResource("/Resources/success-80.png").toExternalForm());
        } else {
            nImage = new Image(getClass().getResource("/Resources/facepalm-80.png").toExternalForm());
        }

        ImageView nIcon = new ImageView(nImage);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(Title);
        alert.setHeaderText(Message);
        alert.setGraphic(nIcon);
        alert.showAndWait();

//        EventQueue.invokeLater(new Runnable() {
//            @Override
//            public void run() {
//                ImageIcon icon = new ImageIcon(getClass().getResource("/Resources/facepalm-80.png"));
//                JOptionPane.showMessageDialog(null, Message, Title, JOptionPane.INFORMATION_MESSAGE, icon);
//            }
//        });
    }
}
