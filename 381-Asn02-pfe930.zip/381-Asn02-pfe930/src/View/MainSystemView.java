package View;

import Controller.MilkshakesController;
import Model.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;

import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.BorderPane;

import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class MainSystemView extends Pane implements MilkshakeModelListener {

    private MilkshakesController Controller;
    private GridPane GridPane;

    private ToppingsView ToppingsView;
    private IceCreamView IceCreamScoopsView;
    private PictureView PictureView;

    private MainSystemModel Model;

    private Label lbl_OrderTotal;
    private Button btn_RestartOrder;
    private Button btn_Checkout;

    public MainSystemView(){

        CreateChildrenViews();
        CreateControls();

        GridPane = new GridPane();
        GridPane.setVgap(10);
        GridPane.setHgap(10);
        GridPane.add(IceCreamScoopsView, 0 , 1);
        GridPane.add(ToppingsView, 0 , 2);

        GridPane.add(PictureView, 1, 1, 1, 2);

        VBox vb_OrderTotal = new VBox();
        vb_OrderTotal.getChildren().add(lbl_OrderTotal);
        vb_OrderTotal.getChildren().add(new Label("Order Total"));
        vb_OrderTotal.setAlignment(Pos.CENTER);

        Label lbl_SystemName = new Label("Milkshake Machine 3000");
        lbl_SystemName.setFont(GetFont());

        HBox hb_TopControls = new HBox();
        hb_TopControls.getChildren().addAll(btn_RestartOrder, lbl_SystemName, btn_Checkout);
        hb_TopControls.setSpacing(200);
        hb_TopControls.setAlignment(Pos.CENTER);

        Label lbl_Instructions = new Label("Build your milkshake by clicking on the '+' and '-' icons to add items.\nAt least one scoop of ice cream is required to build a milkshake.");

        VBox vb_Top = new VBox();
        vb_Top.getChildren().addAll(hb_TopControls, lbl_Instructions);
        vb_Top.setAlignment(Pos.CENTER);

        BorderPane root = new BorderPane();
        root.setTop(vb_Top);
        root.setCenter(GridPane);
        root.setBottom(vb_OrderTotal);

        root.setAlignment(vb_OrderTotal, Pos.CENTER);
        root.setPadding(new Insets(10, 5, 5, 20));

        this.getChildren().add(root);
    }

    private void CreateChildrenViews(){
        // Toppings View \\
        ToppingsView = new ToppingsView();
        ToppingsModel ToppingsModel = new ToppingsModel();
        this.Controller = new MilkshakesController();

        ToppingsView.SetController(Controller);
        ToppingsView.SetModel(ToppingsModel);
        ToppingsModel.AddSubscriber(ToppingsView);

        Controller.SetToppingsModel(ToppingsModel);

        // Ice Cream View \\
        IceCreamScoopsView = new IceCreamView();
        IcecreamScoopsModel IceCreamScoopsModel = new IcecreamScoopsModel();

        IceCreamScoopsView.SetController(Controller);
        IceCreamScoopsView.SetModel(IceCreamScoopsModel);
        IceCreamScoopsModel.AddSubscriber(IceCreamScoopsView);

        Controller.SetIcecreamScoopsModel(IceCreamScoopsModel);

        // Picture View \\
        PictureView = new PictureView(567, 500);
        PictureModel PictureModel = new PictureModel();

        PictureView.SetController(Controller);
        PictureView.SetModel(PictureModel);
        PictureModel.AddSubscriber(PictureView);

        Controller.SetPictureModel(PictureModel);

        // This View \\
        this.Model = new MainSystemModel();
        this.Model.SetIceCreamScoopsModel(IceCreamScoopsModel);
        this.Model.SetToppingsModel(ToppingsModel);
        this.Model.AddSubscriber(this);


        Controller.SetMainSystemModel(this.Model);

    }

    private void CreateControls(){
        lbl_OrderTotal = new Label("$0.00");
        lbl_OrderTotal.setFont(GetFont());
        lbl_OrderTotal.setTextFill(Color.GREEN);

        Image img_Checkout = new Image("/Resources/checkout-40.png");
        btn_Checkout = new Button("Checkout");
        btn_Checkout.setGraphic(new ImageView(img_Checkout));
        btn_Checkout.setOnAction(e -> Controller.btnCheckout());

        Image img_Restart = new Image("/Resources/restart-30.png");
        btn_RestartOrder = new Button("Restart Order");
        btn_RestartOrder.setGraphic(new ImageView(img_Restart));
        btn_RestartOrder.setMinHeight(btn_Checkout.getHeight());
        btn_RestartOrder.setOnAction(e -> Controller.btnRestartOrder());
    }

    private Font GetFont(){ return new Font("Arial", 28); }

    public void Draw(){
        lbl_OrderTotal.setText(Model.GetOrderTotalAsMoneyFormat());
    }


    @Override
    public void modelChanged() {
        this.Draw();
    }
}
