package View;

import Controller.MilkshakesController;
import Model.MilkshakeIcon;
import Model.PictureModel;
import Model.MilkshakeModelListener;
import javafx.geometry.Point2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Pane;

import javafx.scene.canvas.Canvas;

public class PictureView extends Pane implements MilkshakeModelListener {


    private Canvas Canvas;
    private GraphicsContext GC;
    private int Height, Width;

    private MilkshakesController Controller;
    private PictureModel Model;

    public PictureView(int nHeight, int nWidth){
        Height = nHeight;
        Width = nWidth;

        Canvas = new Canvas(Width, Height);
        GC = Canvas.getGraphicsContext2D();

        TitledPane MainGroup = new TitledPane("Your Milkshake Ingredients", Canvas);
        MainGroup.setCollapsible(false);
        MainGroup.setStyle("-fx-border-color: black;");
        MainGroup.setPrefWidth(500);

        this.getChildren().add(MainGroup);
    }

    public void SetController(MilkshakesController nController) {
        this.Controller = nController;
    }

    public void SetModel(PictureModel nModel){
        this.Model = nModel;
    }

    @Override
    public void modelChanged() {
        this.Draw();
    }

    public void Draw(){

        GC.clearRect(0, 0, Canvas.getWidth(), Canvas.getHeight());

        int IconCounts = Model.GetMilkshakeIconArrayListSize();

        for(int i = 0; i <= IconCounts - 1; i++){

            MilkshakeIcon Icon = Model.GetIconAtIndex(i);

            //Get Row for new Icon
            int ColNum = Math.floorMod(i, 4);
            int RowNum = 0;

            if(i >= 0 && i <= 3){
                RowNum = 0;
            } else if (i >= 4 && i <= 7){
                RowNum = 1;
            }else if (i >= 8 && i <= 11){
                RowNum = 2;
            } else {
                RowNum = 3;
            }

            int nXPoint = ((ColNum * 100) + 25);
            int nyPoint  = ((RowNum * 100) + 25);

            Point2D Points = new Point2D(nXPoint,nyPoint);

            GC.drawImage(Icon.getIconImage(), Points.getX(), Points.getY());
        }
    }
}
