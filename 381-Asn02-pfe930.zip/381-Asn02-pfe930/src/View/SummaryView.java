package View;

public class SummaryView {
}
