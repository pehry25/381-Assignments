package View;

import Controller.MilkshakesController;
import Model.IcecreamScoopsModel;
import Model.MilkshakeModelListener;
import Model.ToppingsModel;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.*;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.scene.control.Label;
import javafx.scene.text.Font;

public class IceCreamView extends Pane implements MilkshakeModelListener {

    private MilkshakesController Controller;
    private IcecreamScoopsModel Model;

    private Label lbl_Chocolate;
    private Label lbl_Vanilla;
    private Label lbl_Strawberry;
    private Label lbl_Lemon;
    private Label lbl_Coffee;
    private Label lbl_Mint;

    private Label lbl_ChocolateCount;
    private Label lbl_VanillaCount;
    private Label lbl_StrawberryCount;
    private Label lbl_LemonCount;
    private Label lbl_CoffeeCount;
    private Label lbl_MintCount;

    private Label lbl_ScoopsCount;

    public IceCreamView(){
        lbl_Chocolate = new Label("Chocolate");
        lbl_Vanilla = new Label("Vanilla");
        lbl_Strawberry = new Label("Strawberry Chips");
        lbl_Lemon = new Label("Lemon");
        lbl_Coffee = new Label("Coffee");
        lbl_Mint = new Label("Mint");

        lbl_ChocolateCount = new Label();
        lbl_VanillaCount = new Label();
        lbl_StrawberryCount = new Label();
        lbl_LemonCount = new Label();
        lbl_CoffeeCount = new Label();
        lbl_MintCount = new Label();

        lbl_ScoopsCount = new Label();
    }

    public void SetController(MilkshakesController nController){
        this.Controller = nController;
        this.CreateComponents();
    }

    public void SetModel(IcecreamScoopsModel nModel){
        this.Model = nModel;
        modelChanged();
    }

    private Font GetFont(){ return new Font("Arial", 20); }

    private void CreateComponents(){
        // Create Buttons \\
        Image img_Add = new Image("/Resources/add-20.png");
        Image img_Sub = new Image("/Resources/subtract-20.png");

        Button btn_AddChocolate, btn_RemoveChocolate;
        btn_AddChocolate = new Button("");
        btn_RemoveChocolate = new Button("");
        btn_AddChocolate.setGraphic(new ImageView(img_Add));
        btn_RemoveChocolate.setGraphic(new ImageView(img_Sub));

        btn_AddChocolate.setOnAction(e -> Controller.btnAddChocolate());
        btn_RemoveChocolate.setOnAction(e -> Controller.btnRemoveChocolate());

        Button btn_AddVanilla, btn_RemoveVanilla;
        btn_AddVanilla = new Button("");
        btn_RemoveVanilla = new Button("");
        btn_AddVanilla.setGraphic(new ImageView(img_Add));
        btn_RemoveVanilla.setGraphic(new ImageView(img_Sub));

        btn_AddVanilla.setOnAction(e -> Controller.btnAddVanilla());
        btn_RemoveVanilla.setOnAction(e -> Controller.btnRemoveVanilla());

        Button btn_AddStrawberry, btn_RemoveStrawberry;
        btn_AddStrawberry = new Button("");
        btn_RemoveStrawberry = new Button("");
        btn_AddStrawberry.setGraphic(new ImageView(img_Add));
        btn_RemoveStrawberry.setGraphic(new ImageView(img_Sub));

        btn_AddStrawberry.setOnAction(e -> Controller.btnAddStrawberry());
        btn_RemoveStrawberry.setOnAction(e -> Controller.btnRemoveStrawberry());

        Button btn_AddLemon, btn_RemoveLemon;
        btn_AddLemon = new Button("");
        btn_RemoveLemon = new Button("");
        btn_AddLemon.setGraphic(new ImageView(img_Add));
        btn_RemoveLemon.setGraphic(new ImageView(img_Sub));

        btn_AddLemon.setOnAction(e -> Controller.btnAddLemon());
        btn_RemoveLemon.setOnAction(e -> Controller.btnRemoveLemon());

        Button btn_AddCoffee, btn_RemoveCoffee;
        btn_AddCoffee = new Button("");
        btn_RemoveCoffee = new Button("");
        btn_AddCoffee.setGraphic(new ImageView(img_Add));
        btn_RemoveCoffee.setGraphic(new ImageView(img_Sub));

        btn_AddCoffee.setOnAction(e -> Controller.btnAddCoffee());
        btn_RemoveCoffee.setOnAction(e -> Controller.btnRemoveCoffee());

        Button btn_AddMint, btn_RemoveMint;
        btn_AddMint = new Button("");
        btn_RemoveMint = new Button("");
        btn_AddMint.setGraphic(new ImageView(img_Add));
        btn_RemoveMint.setGraphic(new ImageView(img_Sub));

        btn_AddMint.setOnAction(e -> Controller.btnAddMint());
        btn_RemoveMint.setOnAction(e -> Controller.btnRemoveMint());

        // Create Toppings Type Labels \\

        lbl_Chocolate.setFont(GetFont());
        lbl_Vanilla.setFont(GetFont());
        lbl_Strawberry.setFont(GetFont());
        lbl_Lemon.setFont(GetFont());
        lbl_Coffee.setFont(GetFont());
        lbl_Mint.setFont(GetFont());

        lbl_Chocolate.setPadding(new Insets(5, 30, 0, 0));
        lbl_Vanilla.setPadding(new Insets(5, 30, 0, 0));
        lbl_Strawberry.setPadding(new Insets(5, 30, 0, 0));
        lbl_Lemon.setPadding(new Insets(5, 30, 0, 0));
        lbl_Coffee.setPadding(new Insets(5, 30, 0, 0));
        lbl_Mint.setPadding(new Insets(5, 30, 0, 0));

        lbl_ChocolateCount.setFont(GetFont());
        lbl_VanillaCount.setFont(GetFont());
        lbl_StrawberryCount.setFont(GetFont());
        lbl_LemonCount.setFont(GetFont());
        lbl_CoffeeCount.setFont(GetFont());
        lbl_MintCount.setFont(GetFont());

        lbl_ChocolateCount.setPadding(new Insets(5,5,0,5));
        lbl_VanillaCount.setPadding(new Insets(5,5,0,5));
        lbl_StrawberryCount.setPadding(new Insets(5,5,0,5));
        lbl_LemonCount.setPadding(new Insets(5,5,0,5));
        lbl_CoffeeCount.setPadding(new Insets(5,5,0,5));
        lbl_MintCount.setPadding(new Insets(5,5,0,5));

        lbl_ScoopsCount.setAlignment(Pos.CENTER_RIGHT);
        lbl_ScoopsCount.setPadding(new Insets(10,0,0,0));

        // Create the Controls Pane \\
        GridPane ControlsPane = new GridPane();
        ControlsPane.setVgap(5);
        ControlsPane.setHgap(5);
        ControlsPane.setAlignment(Pos.CENTER);

        ControlsPane.add(lbl_Chocolate, 0, 0);
        ControlsPane.add(lbl_Vanilla, 0, 1);
        ControlsPane.add(lbl_Strawberry, 0, 2);
        ControlsPane.add(lbl_Lemon, 0, 3);
        ControlsPane.add(lbl_Coffee, 0, 4);
        ControlsPane.add(lbl_Mint, 0, 5);

        ControlsPane.add(btn_AddChocolate, 3, 0);
        ControlsPane.add(btn_AddVanilla, 3, 1);
        ControlsPane.add(btn_AddStrawberry, 3, 2);
        ControlsPane.add(btn_AddLemon, 3, 3);
        ControlsPane.add(btn_AddCoffee, 3, 4);
        ControlsPane.add(btn_AddMint, 3, 5);

        ControlsPane.add(lbl_ChocolateCount, 2, 0);
        ControlsPane.add(lbl_VanillaCount, 2, 1);
        ControlsPane.add(lbl_StrawberryCount, 2, 2);
        ControlsPane.add(lbl_LemonCount, 2, 3);
        ControlsPane.add(lbl_CoffeeCount, 2, 4);
        ControlsPane.add(lbl_MintCount, 2, 5);

        ControlsPane.add(btn_RemoveChocolate, 1 ,0);
        ControlsPane.add(btn_RemoveVanilla, 1 ,1);
        ControlsPane.add(btn_RemoveStrawberry, 1 ,2);
        ControlsPane.add(btn_RemoveLemon, 1 ,3);
        ControlsPane.add(btn_RemoveCoffee, 1 ,4);
        ControlsPane.add(btn_RemoveMint, 1 ,5);

        ControlsPane.setPadding(new Insets(5,0,5,0));

        // Create the Scopps Pane \\
        BorderPane bp_ScoopsPane = new BorderPane();
        bp_ScoopsPane.setCenter(ControlsPane);
        bp_ScoopsPane.setBottom(lbl_ScoopsCount);
        bp_ScoopsPane.setAlignment(lbl_ScoopsCount,Pos.CENTER_RIGHT);

        TitledPane MainGroup = new TitledPane("Select Ice Cream Scoops | $1.00 Each", bp_ScoopsPane);
        MainGroup.setCollapsible(false);
        MainGroup.setStyle("-fx-border-color: black;");
        MainGroup.setPrefWidth(500);

        this.getChildren().add(MainGroup);

    }

    @Override
    public void modelChanged() { Draw(); }

    public void Draw(){
        // Update Counts
        lbl_ChocolateCount.setText(Integer.toString(Model.GetChocolateCount()));
        lbl_VanillaCount.setText(Integer.toString(Model.GetVanillaCount()));
        lbl_StrawberryCount.setText(Integer.toString(Model.GetStrawberryCount()));
        lbl_LemonCount.setText(Integer.toString(Model.GetLemonCount()));
        lbl_CoffeeCount.setText(Integer.toString(Model.GetCoffeeCount()));
        lbl_MintCount.setText(Integer.toString(Model.GetMintCount()));
        lbl_ScoopsCount.setText(Integer.toString(Model.GetScoopsCount()) + " of 8 selected");
    }
}
