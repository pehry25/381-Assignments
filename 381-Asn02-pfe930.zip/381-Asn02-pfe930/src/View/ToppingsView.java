package View;

import Controller.MilkshakesController;
import Model.MilkshakeModelListener;
import Model.ToppingsModel;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.*;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.scene.control.Label;
import javafx.scene.text.Font;

import javax.swing.*;
import java.awt.*;

public class ToppingsView extends Pane implements MilkshakeModelListener {

    private MilkshakesController Controller;
    private ToppingsModel Model;

    public Label lbl_SprinklesCount, lbl_CherriesCount, lbl_ChocolateChipsCount, lbl_WhippedCreamCount, lbl_CoconutCount, lbl_MarshmallowsCount, lbl_ToppingsCount;

    public ToppingsView(){

    }

    public void SetController(MilkshakesController nController){
        this.Controller = nController;
        this.CreateComponents();
    }

    public void SetModel(ToppingsModel nModel){
        this.Model = nModel;
        modelChanged();
    }

    private void CreateComponents(){
        // Create Buttons \\
        Image img_Add = new Image("/Resources/add-20.png");
        Image img_Sub = new Image("/Resources/subtract-20.png");

        Button btn_AddSprinkles, btn_RemoveSprinkles;
        btn_AddSprinkles = new Button("");
        btn_RemoveSprinkles = new Button("");
        btn_AddSprinkles.setGraphic(new ImageView(img_Add));
        btn_RemoveSprinkles.setGraphic(new ImageView(img_Sub));

        btn_AddSprinkles.setOnAction(e -> Controller.btnAddSprinkles());
        btn_RemoveSprinkles.setOnAction(e -> Controller.btnRemoveSprinkles());

        Button btn_AddCherries, btn_RemoveCherries;
        btn_AddCherries = new Button("");
        btn_RemoveCherries = new Button("");
        btn_AddCherries.setGraphic(new ImageView(img_Add));
        btn_RemoveCherries.setGraphic(new ImageView(img_Sub));

        btn_AddCherries.setOnAction(e -> Controller.btnAddCherries());
        btn_RemoveCherries.setOnAction(e -> Controller.btnRemoveCherries());

        Button btn_AddChocolateChips, btn_RemoveChocolateChips;
        btn_AddChocolateChips = new Button("");
        btn_RemoveChocolateChips = new Button("");
        btn_AddChocolateChips.setGraphic(new ImageView(img_Add));
        btn_RemoveChocolateChips.setGraphic(new ImageView(img_Sub));

        btn_AddChocolateChips.setOnAction(e -> Controller.btnAddChocolateChips());
        btn_RemoveChocolateChips.setOnAction(e -> Controller.btnRemoveChocolateChips());

        Button btn_AddWhippedCream, btn_RemoveWhippedCream;
        btn_AddWhippedCream = new Button("");
        btn_RemoveWhippedCream = new Button("");
        btn_AddWhippedCream.setGraphic(new ImageView(img_Add));
        btn_RemoveWhippedCream.setGraphic(new ImageView(img_Sub));

        btn_AddWhippedCream.setOnAction(e -> Controller.btnAddWhippedCream());
        btn_RemoveWhippedCream.setOnAction(e -> Controller.btnRemoveWhippedCream());

        Button btn_AddCoconut, btn_RemoveCoconut;
        btn_AddCoconut = new Button("");
        btn_RemoveCoconut = new Button("");
        btn_AddCoconut.setGraphic(new ImageView(img_Add));
        btn_RemoveCoconut.setGraphic(new ImageView(img_Sub));

        btn_AddCoconut.setOnAction(e -> Controller.btnAddCoconut());
        btn_RemoveCoconut.setOnAction(e -> Controller.btnRemoveCoconut());

        Button btn_AddMarshmallows, btn_RemoveMarshmallows;
        btn_AddMarshmallows = new Button("");
        btn_RemoveMarshmallows = new Button("");
        btn_AddMarshmallows.setGraphic(new ImageView(img_Add));
        btn_RemoveMarshmallows.setGraphic(new ImageView(img_Sub));

        btn_AddMarshmallows.setOnAction(e -> Controller.btnAddMarshmallows());
        btn_RemoveMarshmallows.setOnAction(e -> Controller.btnRemoveMarshmallows());

        // Create Toppings Type Labels \\
        Label lbl_Sprinkles, lbl_Cherries, lbl_ChocolateChips, lbl_WhippedCream, lbl_Coconut, lbl_Marshmallows;
        lbl_Sprinkles = new Label("Sprinkles");
        lbl_Cherries = new Label("Cherries");
        lbl_ChocolateChips = new Label("Chocolate Chips");
        lbl_WhippedCream = new Label("Whipped Cream");
        lbl_Coconut = new Label("Coconut");
        lbl_Marshmallows = new Label("Marshmallows");

        lbl_Sprinkles.setFont(GetFont());
        lbl_Cherries.setFont(GetFont());
        lbl_ChocolateChips.setFont(GetFont());
        lbl_WhippedCream.setFont(GetFont());
        lbl_Coconut.setFont(GetFont());
        lbl_Marshmallows.setFont(GetFont());

        lbl_Sprinkles.setPadding(new Insets(5, 30, 0, 0));
        lbl_Cherries.setPadding(new Insets(5, 30, 0, 0));
        lbl_ChocolateChips.setPadding(new Insets(5, 30, 0, 0));
        lbl_WhippedCream.setPadding(new Insets(5, 30, 0, 0));
        lbl_Coconut.setPadding(new Insets(5, 30, 0, 0));
        lbl_Marshmallows.setPadding(new Insets(5, 30, 0, 0));

        // Create Count Labels \\
        lbl_SprinklesCount = new Label();
        lbl_CherriesCount = new Label();
        lbl_ChocolateChipsCount = new Label();
        lbl_WhippedCreamCount = new Label();
        lbl_CoconutCount = new Label();
        lbl_MarshmallowsCount = new Label();

        lbl_SprinklesCount.setFont(GetFont());
        lbl_CherriesCount.setFont(GetFont());
        lbl_ChocolateChipsCount.setFont(GetFont());
        lbl_WhippedCreamCount.setFont(GetFont());
        lbl_CoconutCount.setFont(GetFont());
        lbl_MarshmallowsCount.setFont(GetFont());

        lbl_SprinklesCount.setPadding(new Insets(5,5,0,5));
        lbl_CherriesCount.setPadding(new Insets(5,5,0,5));
        lbl_ChocolateChipsCount.setPadding(new Insets(5,5,0,5));
        lbl_WhippedCreamCount.setPadding(new Insets(5,5,0,5));
        lbl_CoconutCount.setPadding(new Insets(5,5,0,5));
        lbl_MarshmallowsCount.setPadding(new Insets(5,5,0,5));

        lbl_ToppingsCount = new Label();
        lbl_ToppingsCount.setAlignment(Pos.CENTER_RIGHT);
        lbl_ToppingsCount.setPadding(new Insets(10,0,0,0));

        // Create the Controls Pane \\
        GridPane ControlsPane = new GridPane();
        ControlsPane.setVgap(5);
        ControlsPane.setHgap(5);
        ControlsPane.setAlignment(Pos.CENTER);

        ControlsPane.add(lbl_Sprinkles, 0, 0);
        ControlsPane.add(lbl_Cherries, 0, 1);
        ControlsPane.add(lbl_ChocolateChips, 0, 2);
        ControlsPane.add(lbl_WhippedCream, 0, 3);
        ControlsPane.add(lbl_Coconut, 0, 4);
        ControlsPane.add(lbl_Marshmallows, 0, 5);

        ControlsPane.add(btn_AddSprinkles, 3, 0);
        ControlsPane.add(btn_AddCherries, 3, 1);
        ControlsPane.add(btn_AddChocolateChips, 3, 2);
        ControlsPane.add(btn_AddWhippedCream, 3, 3);
        ControlsPane.add(btn_AddCoconut, 3, 4);
        ControlsPane.add(btn_AddMarshmallows, 3, 5);

        ControlsPane.add(lbl_SprinklesCount, 2, 0);
        ControlsPane.add(lbl_CherriesCount, 2, 1);
        ControlsPane.add(lbl_ChocolateChipsCount, 2, 2);
        ControlsPane.add(lbl_WhippedCreamCount, 2, 3);
        ControlsPane.add(lbl_CoconutCount, 2, 4);
        ControlsPane.add(lbl_MarshmallowsCount, 2, 5);

        ControlsPane.add(btn_RemoveSprinkles, 1 ,0);
        ControlsPane.add(btn_RemoveCherries, 1 ,1);
        ControlsPane.add(btn_RemoveChocolateChips, 1 ,2);
        ControlsPane.add(btn_RemoveWhippedCream, 1 ,3);
        ControlsPane.add(btn_RemoveCoconut, 1 ,4);
        ControlsPane.add(btn_RemoveMarshmallows, 1 ,5);

        ControlsPane.setPadding(new Insets(5,0,5,0));

        // Create the Toppings Pane \\
        BorderPane bp_ToppingsPane = new BorderPane();
        bp_ToppingsPane.setCenter(ControlsPane);
        bp_ToppingsPane.setBottom(lbl_ToppingsCount);
        bp_ToppingsPane.setAlignment(lbl_ToppingsCount,Pos.CENTER_RIGHT);

        TitledPane MainGroup = new TitledPane("Select Toppings | $0.50 Each", bp_ToppingsPane);
        MainGroup.setCollapsible(false);
        MainGroup.setStyle("-fx-border-color: black;");
        MainGroup.setPrefWidth(500);

        this.getChildren().add(MainGroup);
    }

    private Font GetFont(){ return new Font("Arial", 20); }

    public void Draw(){
        // Update Counts
        lbl_SprinklesCount.setText(Integer.toString(Model.GetSprinklesCount()));
        lbl_CherriesCount.setText(Integer.toString(Model.GetCherriesCount()));
        lbl_ChocolateChipsCount.setText(Integer.toString(Model.GetChocolateChipsCount()));
        lbl_WhippedCreamCount.setText(Integer.toString(Model.GetWhippedCreamCount()));
        lbl_CoconutCount.setText(Integer.toString(Model.GetCoconutCount()));
        lbl_MarshmallowsCount.setText(Integer.toString(Model.GetMarshmallowsCount()));
        lbl_ToppingsCount.setText(Integer.toString(Model.GetToppingsCount()) + " of 6 selected");
    }

    @Override
    public void modelChanged() {
        Draw();
    }
}
