import Controller.MilkshakesController;
import Model.MilkshakeModelListener;
import Model.ToppingsModel;
import View.MainSystemView;
import View.ToppingsView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{

        MainSystemView View = new MainSystemView();

        primaryStage.setTitle("Milkshake Maker 3000");
        primaryStage.setScene(new Scene(View, 1200, 800));
        primaryStage.show();

    }


    public static void main(String[] args) {
        launch(args);
    }
}
