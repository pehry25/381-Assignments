package Controller;

import Model.IcecreamScoopsModel;
import Model.MainSystemModel;
import Model.PictureModel;
import Model.ToppingsModel;
import View.DisplayMissage;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;

public class MilkshakesController {

    private ToppingsModel ToppingsModel;
    private IcecreamScoopsModel IcecreamScoopsModel;
    private PictureModel PictureModel;
    private MainSystemModel MainSystemModel;

    public MilkshakesController(){
    }

    public void SetToppingsModel(ToppingsModel nModel){
        this.ToppingsModel = nModel;
    }
    public void SetIcecreamScoopsModel(IcecreamScoopsModel nModel) { this.IcecreamScoopsModel = nModel; }
    public void SetPictureModel(PictureModel nModel) { this.PictureModel = nModel; }
    public void SetMainSystemModel(MainSystemModel nModel){
        this.MainSystemModel = nModel;
    }

    public void btnAddSprinkles() {

        if(ToppingsModel.IncreaseSprinklesCount()){
            PictureModel.AddMilkshakeIcon("Sprinkles");
            MainSystemModel.CalculateOrderTotal();
        }
    }

    public void btnRemoveSprinkles() {
        ToppingsModel.DecreaseSprinklesCount();
        PictureModel.RemoveMilkshakeIcon("Sprinkles");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnAddCherries() {
        if(ToppingsModel.IncreaseCherriesCount()){
            PictureModel.AddMilkshakeIcon("Cherries");
            MainSystemModel.CalculateOrderTotal();
        }
    }

    public void btnRemoveCherries() {
        ToppingsModel.DecreaseCherriesCount();
        PictureModel.RemoveMilkshakeIcon("Cherries");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnAddChocolateChips(){
        if(ToppingsModel.IncreaseChocolateChipsCount()){
            PictureModel.AddMilkshakeIcon("ChocolateChips");
            MainSystemModel.CalculateOrderTotal();
        }
    }

    public void btnRemoveChocolateChips(){
        ToppingsModel.DecreaseChocolateChipsCount();
        PictureModel.RemoveMilkshakeIcon("ChocolateChips");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnAddWhippedCream() {
        if(ToppingsModel.IncreaseWhippedCreamCount()){
            PictureModel.AddMilkshakeIcon("WhippedCream");
            MainSystemModel.CalculateOrderTotal();
        }
    }

    public void btnRemoveWhippedCream() {
        ToppingsModel.DecreaseWhippedCreamCount();
        PictureModel.RemoveMilkshakeIcon("WhippedCream");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnAddCoconut() {
        if(ToppingsModel.IncreaseCoconutCount()){
            PictureModel.AddMilkshakeIcon("Coconut");
            MainSystemModel.CalculateOrderTotal();
        }
    }

    public void btnRemoveCoconut() {
        ToppingsModel.DecreaseCoconutCount();
        PictureModel.RemoveMilkshakeIcon("Coconut");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnAddMarshmallows() {
        if(ToppingsModel.IncreaseMarshmallowsCount()){
            PictureModel.AddMilkshakeIcon("Marshmallows");
            MainSystemModel.CalculateOrderTotal();
        }
    }

    public void btnRemoveMarshmallows() {
        ToppingsModel.DecreaseMarshmallowsCount();
        PictureModel.RemoveMilkshakeIcon("Marshmallows");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnAddChocolate() {
        if(IcecreamScoopsModel.IncreaseChocolateCount()){
            PictureModel.AddMilkshakeIcon("Chocolate");
            MainSystemModel.CalculateOrderTotal();
        }
    }
    public void btnRemoveChocolate() {
        IcecreamScoopsModel.DecreaseChocolateCount();
        PictureModel.RemoveMilkshakeIcon("Chocolate");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnAddVanilla() {
        if(IcecreamScoopsModel.IncreaseVanillaCount()){
            PictureModel.AddMilkshakeIcon("Vanilla");
            MainSystemModel.CalculateOrderTotal();
        }
    }
    public void btnRemoveVanilla() {
        IcecreamScoopsModel.DecreaseVanillaCount();
        PictureModel.RemoveMilkshakeIcon("Vanilla");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnAddStrawberry() {
        if(IcecreamScoopsModel.IncreaseStrawberryCount()){
            PictureModel.AddMilkshakeIcon("Strawberry");
            MainSystemModel.CalculateOrderTotal();
        }
    }
    public void btnRemoveStrawberry() {
        IcecreamScoopsModel.DecreaseStrawberryCount();
        PictureModel.RemoveMilkshakeIcon("Strawberry");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnAddLemon() {
        if(IcecreamScoopsModel.IncreaseLemonCount()){
            PictureModel.AddMilkshakeIcon("Lemon");
            MainSystemModel.CalculateOrderTotal();
        }
    }
    public void btnRemoveLemon() {
        IcecreamScoopsModel.DecreaseLemonCount();
        PictureModel.RemoveMilkshakeIcon("Lemon");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnAddCoffee() {
        if(IcecreamScoopsModel.IncreaseCoffeeCount()){
            PictureModel.AddMilkshakeIcon("Coffee");
            MainSystemModel.CalculateOrderTotal();
        }
    }

    public void btnRemoveCoffee() {
        IcecreamScoopsModel.DecreaseCoffeeCount();
        PictureModel.RemoveMilkshakeIcon("Coffee");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnAddMint() {
        if(IcecreamScoopsModel.IncreaseMintCount()){
            PictureModel.AddMilkshakeIcon("Mint");
            MainSystemModel.CalculateOrderTotal();
        }
    }

    public void btnRemoveMint() {
        IcecreamScoopsModel.DecreaseMintCount();
        PictureModel.RemoveMilkshakeIcon("Mint");
        MainSystemModel.CalculateOrderTotal();
    }

    public void btnCheckout(){
        if(IcecreamScoopsModel.GetScoopsCount() > 0){

            String nToppings = ToppingsModel.GetAllToppings();
            String nScoops = IcecreamScoopsModel.GetAllScoops();
            String nOrderTotal = MainSystemModel.GetOrderTotalAsMoneyFormat();

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Checkout?");
            alert.setContentText("Order Details:\n" + nScoops + "\n" + nToppings + "\n" + "Order Total: " + nOrderTotal );
            ButtonType okButton = new ButtonType("Place Order", ButtonBar.ButtonData.YES);
            ButtonType noButton = new ButtonType("Cancel", ButtonBar.ButtonData.NO);
            //alert.getButtonTypes().setAll(okButton, noButton);
            alert.showAndWait().ifPresent(type -> {
                if (type == ButtonType.OK) {

                    new DisplayMissage("Thank-you!", "Your order has been placed!", 0);

                    IcecreamScoopsModel.ClearScoops();
                    ToppingsModel.ClearToppings();
                    PictureModel.RemoveAllIcons();
                    MainSystemModel.CalculateOrderTotal();
                } else {
                    System.out.println("User cancelled the clear order.");
                }
            });
        } else {
            new DisplayMissage("Oops!", "You must select at least one scoop of ice cream in order to place an order.", 1);
        }
    }

    public void btnRestartOrder(){

        if(MainSystemModel.GetOrderTotalAsDouble() > 0){
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Clear order?");
            alert.setContentText("Do you want to clear your entire order?");
            ButtonType okButton = new ButtonType("Yes", ButtonBar.ButtonData.YES);
            ButtonType noButton = new ButtonType("No", ButtonBar.ButtonData.NO);
            //alert.getButtonTypes().setAll(okButton, noButton);
            alert.showAndWait().ifPresent(type -> {
                if (type == ButtonType.OK) {
                    IcecreamScoopsModel.ClearScoops();
                    ToppingsModel.ClearToppings();
                    PictureModel.RemoveAllIcons();
                    MainSystemModel.CalculateOrderTotal();
                } else {
                    System.out.println("User cancelled the clear order.");
                }
            });
        } else {
            System.out.println("User attempted to clear a blank order.");
        }
    }

}
