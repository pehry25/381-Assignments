package sample;

import javafx.application.Application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.awt.*;

public class Main extends Application {

    protected HBox root;
    protected BorderPane topPanel;
    protected VBox midPanel;
    protected VBox bottomPanel;

    protected Label Items;
    protected Label ItemCount;
    protected Label Price;
    protected Label PriceTotal;

    protected Button btn_Home;

    protected double OrderTotal;
    protected int ItemsTotal;

    @Override
    public void start(Stage primaryStage) throws Exception{

        // Assign values to the System Data variables
        OrderTotal = 0.00;
        ItemsTotal = 0;

        // Declare the Content Views
        BorderPane root = new BorderPane();
        topPanel = new BorderPane();
        midPanel = new VBox();
        bottomPanel = new VBox();

        root.setTop(topPanel);
        root.setCenter(midPanel);
        root.setBottom(bottomPanel);

        // Create the Item and Price views
        Items = new Label("Items: ");
        ItemCount = new Label("0");
        Price = new Label("Total: $ ");
        PriceTotal = new Label("0.00");

        btn_Home = new Button("Home");

        HBox ItemInfo = new HBox();
        ItemInfo.getChildren().addAll(Items, ItemCount);

        HBox PriceInfo = new HBox();
        PriceInfo.getChildren().addAll(Price, PriceTotal);

        HBox orderInfo = new HBox();
        orderInfo.setSpacing(10);
        orderInfo.getChildren().addAll(ItemInfo, PriceInfo);

        topPanel.setLeft(orderInfo);
        topPanel.setRight(btn_Home);


        // Create the MID Views for Item Selections
        Label Lbl_IceCream = new Label("Ice Cream");
        Label Lbl_Toppings = new Label("Toppings");
        Label Lbl_Flavorings = new Label("Flavourings");

        ListView LV_IceCreamTypes = new ListView();
        ListView LV_ToppingsTypes = new ListView();
        ListView LV_Flavourings = new ListView();

        LV_IceCreamTypes.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        LV_ToppingsTypes.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        LV_Flavourings.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        LV_IceCreamTypes.getItems().addAll("Chocolate", "Vanilla", "Strawberry", "Neapolitan");
        LV_ToppingsTypes.getItems().addAll("Oreos", "Smarties", "Skor Bits", "Chocolate Chunks");
        LV_Flavourings.getItems().addAll("Chocolate", "Caramel", "Strawberry", "Cherry");

        VBox VB_IceCream = new VBox();
        VB_IceCream.getChildren().addAll(Lbl_IceCream, LV_IceCreamTypes);

        VBox VB_Toppings = new VBox();
        VB_Toppings.getChildren().addAll(Lbl_Toppings, LV_ToppingsTypes);

        VBox VB_Flavourings = new VBox();
        VB_Flavourings.getChildren().addAll(Lbl_Flavorings, LV_Flavourings);

        midPanel.setSpacing(10);
        midPanel.getChildren().addAll(VB_IceCream, VB_Toppings, VB_Flavourings);

        // Set the Bottom Navigation views
        BorderPane BottomNav = new BorderPane();
        Button btn_GoBack = new Button("Go Back");
        Button btn_AddToOrder = new Button("Add To Order");
        BottomNav.setLeft(btn_GoBack);
        BottomNav.setRight(btn_AddToOrder);

        bottomPanel.getChildren().addAll(BottomNav);

        // Set the Button Action Events
        btn_GoBack.setOnAction(e -> GoBackClick());
        btn_Home.setOnAction(e -> GoHomeClick());
        btn_AddToOrder.setOnAction(e -> AddToOrderClick());

 //       Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("Milkshake Machine | Customize");
        primaryStage.setScene(new Scene(root, 400, 375));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }

    private void GoBackClick(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Action Event");
        alert.setHeaderText("Action");
        alert.setContentText("User pressed the Go Back button.");

        alert.showAndWait();
    }

    private void GoHomeClick(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Action Event");
        alert.setHeaderText("Action");
        alert.setContentText("User pressed the Go Home button.");

        alert.showAndWait();
    }

    private void AddToOrderClick(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Action Event");
        alert.setHeaderText("Action");
        alert.setContentText("User pressed the Add To Order button.");

        alert.showAndWait();
    }
}
