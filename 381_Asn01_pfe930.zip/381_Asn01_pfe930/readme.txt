CMPT 381 Assignment 1 | Part 2: Building the GUI

Peter Ehry, pfe930, 11153336

Running the Application
All a user has to do is unzip this file, import the codebase into IntelliJ and click Run at the top of the screen.

The functionality is minimal, so clicking on buttons only fire popup events.